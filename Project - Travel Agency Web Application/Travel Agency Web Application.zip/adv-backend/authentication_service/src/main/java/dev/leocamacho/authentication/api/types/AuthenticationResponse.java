package dev.leocamacho.authentication.api.types;

public record AuthenticationResponse(String token) {
}