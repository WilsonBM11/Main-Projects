# Eureka

- Eureka console: http://localhost:8761/