rootProject.name = "flights-service"
