package dev.flights.api.types;

public record CancelFlightRequest(
    String seatId
) {
}
