package dev.flights.api.types;

public record RegisterAirlineRequest(
        String airline
) {
}
