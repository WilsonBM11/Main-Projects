package dev.flights.api.types;

public record SearchByDestinationRequest (
    String destination
){}
