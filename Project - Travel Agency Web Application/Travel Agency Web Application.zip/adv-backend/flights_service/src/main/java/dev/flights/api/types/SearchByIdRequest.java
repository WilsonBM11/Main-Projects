package dev.flights.api.types;

public record SearchByIdRequest(
        String id
) {
}
