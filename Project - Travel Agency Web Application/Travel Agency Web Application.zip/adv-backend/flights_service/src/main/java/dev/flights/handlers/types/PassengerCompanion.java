package dev.flights.handlers.types;

public record PassengerCompanion(

        String name,
        String dateOfBirth

) {
}
