package dev.hotel_service.api.types;

public record SearchHotelsByAddressRequest(String address) {
}
