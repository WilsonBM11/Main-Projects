package dev.hotel_service.api.types;

public record SearchHotelsByNameRequest (String name){
}
