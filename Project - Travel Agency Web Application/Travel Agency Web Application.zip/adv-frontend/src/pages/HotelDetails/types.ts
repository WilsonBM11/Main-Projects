
export type roomReservationRequest = {
    startDate: string
    endDate: string
    userEmail: string
    roomId: string
};