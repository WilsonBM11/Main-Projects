
export interface LoginForm {
	username: string;
	password: string;
}
