export type RegisterAirline = {
    airline:string
}