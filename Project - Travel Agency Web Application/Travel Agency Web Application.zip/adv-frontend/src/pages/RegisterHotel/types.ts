
export type registerHotelForm = {
    name:string
    phoneNumber:number
    email:string
    address:string
    facilities:string []   
}