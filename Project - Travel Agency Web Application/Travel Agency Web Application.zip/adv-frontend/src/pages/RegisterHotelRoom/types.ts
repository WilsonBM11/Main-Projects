export type registerRoomForm = {
    roomNumber:number
    details:string
    price:number
    available:boolean
    hotelId:string
}