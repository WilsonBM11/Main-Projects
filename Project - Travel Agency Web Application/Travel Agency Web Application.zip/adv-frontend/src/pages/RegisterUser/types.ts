export type RegisterForm = {
    username: string;
    email: string;
    password: string;
};