const requiredFieldRule = { required: true, message: 'Campo requerido' };

export const validationSchema = {
	requiredFieldRule,
};
